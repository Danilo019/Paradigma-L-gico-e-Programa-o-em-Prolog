# prologstuff
prolog stuff I did my professor requested
